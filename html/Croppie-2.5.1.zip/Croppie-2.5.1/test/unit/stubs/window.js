var document;

document = require('./document');

window = {
	document : document
};

module.exports = window;